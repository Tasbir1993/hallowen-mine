//
//  tableTableViewController.swift
//  hallowen
//
//  Created by Tasbir Singh on 2017-11-09.
//  Copyright © 2017 macstudent. All rights reserved.
//

import UIKit
var myIndex = 0
var house = ["address1","address1","address1","address1"]
var image = ["house1", "house2","house3", "house4"]
var candy = [1,2,3,4]
class tableTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
print(house.count)
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        print(house.count)
        return house.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! cellviewTableViewCell
        
        cell.address.text = house[indexPath.row]
        if(UIImage(named: (image[indexPath.row] )) != nil){
            cell.houseImage.image = UIImage(named: (image[indexPath.row] ))
        }else{
            
        }
        
        let smily = candy[indexPath.row]
        if(smily > 0 && smily <= 1){
            cell.smily.image = UIImage(named: "sad hallowen")
        }else if( smily >= 2 && smily <= 4){
            cell.smily.image = UIImage(named: "normal hallowen")
        }else if(smily >= 5){
            cell.smily.image = UIImage(named: "happy hallowen")
        }
        // Configure the cell...
        
        return cell
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex = indexPath.row
        performSegue(withIdentifier: "showdetail", sender: self)
    }
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        house.remove(at: indexPath.row)
        candy.remove(at: indexPath.row)
        image.remove(at: indexPath.row)
        let Index = [indexPath]
        tableView.deleteRows(at: Index, with: .automatic)
    }

    

}
