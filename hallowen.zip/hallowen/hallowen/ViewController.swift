//
//  ViewController.swift
//  hallowen
//
//  Created by Tasbir Singh on 2017-11-09.
//  Copyright © 2017 macstudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var cand: UILabel!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var houseImg: UIImageView!
    @IBOutlet weak var smilyImg: UIImageView!
    override func viewDidLoad() {
        houseImg.image = UIImage(named: image[myIndex])
        address.text = house[myIndex]
        cand.text = String(candy[myIndex])
        let smile = candy[myIndex]
        if(smile > 0 && smile <= 1){
            smilyImg.image = UIImage(named: "sad hallowen")
        }else if( smile >= 2 && smile <= 4){
            smilyImg.image = UIImage(named: "normal hallowen")
        }else if(smile >= 5){
            smilyImg.image = UIImage(named: "happy hallowen")
        }
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

