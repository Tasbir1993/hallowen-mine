//
//  cellviewTableViewCell.swift
//  hallowen
//
//  Created by Tasbir Singh on 2017-11-09.
//  Copyright © 2017 macstudent. All rights reserved.
//

import UIKit

class cellviewTableViewCell: UITableViewCell {

    @IBOutlet weak var smily: UIImageView!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var houseImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
